package javaricci.com.br.controller;

import javaricci.com.br.model.CalculadoraHPModel;
import javaricci.com.br.view.CalculadoraHPView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Controller da Calculadora HP12C - Responsável pela coordenação entre Model e View
 */
public class CalculadoraHPController {
    private final CalculadoraHPModel model;
    private final CalculadoraHPView view;
    
    private boolean digitarNovoNumero = true;
    private String ultimaFuncaoFinanceira = "";
    private final DecimalFormat formatoNumerico;
    
    public CalculadoraHPController(CalculadoraHPModel model, CalculadoraHPView view) {
        this.model = model;
        this.view = view;
        
        // Configura formato numérico para usar ponto como separador decimal
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        symbols.setDecimalSeparator('.');
        symbols.setGroupingSeparator(',');
        formatoNumerico = new DecimalFormat("#,##0.00", symbols);
        formatoNumerico.setGroupingUsed(false); // Não usar separadores de milhar
        
        configurarListeners();
        atualizarView();
    }
    
    private void configurarListeners() {
        // Listeners para botões numéricos
        for (int i = 0; i < 10; i++) {
            final int numero = i;
            view.addBotaoNumericoListener(numero, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarDigito(String.valueOf(numero));
                }
            });
        }
        
        // Listener para ponto decimal
        view.addBotaoPontoListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarPontoDecimal();
            }
        });
        
        // Listeners para operações básicas
        String[] operacoes = {"+", "-", "*", "/"};
        for (String operacao : operacoes) {
            view.addBotaoOperacaoListener(operacao, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    executarOperacao(operacao);
                }
            });
        }
        
        // Listener para igual
        view.addBotaoIgualListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finalizarOperacao();
            }
        });
        
        // Listener para limpar
        view.addBotaoLimparListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limparTudo();
            }
        });
        
        // Listener para CHS (mudar sinal)
        view.addBotaoCHSListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alternarSinal();
            }
        });
        
        // Listener para ENTER
        view.addBotaoEnterListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executarEnter();
            }
        });
        
        // Listeners para funções financeiras
        String[] funcoesFinanceiras = {
            CalculadoraHPModel.VP,
            CalculadoraHPModel.VF,
            CalculadoraHPModel.PMT,
            CalculadoraHPModel.TAXA,
            CalculadoraHPModel.PERIODO
        };
        
        for (String funcao : funcoesFinanceiras) {
            view.addBotaoFinanceiroListener(funcao, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    executarFuncaoFinanceira(funcao);
                }
            });
        }
    }
    
    private void adicionarDigito(String digito) {
        String textoAtual = view.getTextoVisor();
        
        // Remove símbolo % se presente
        textoAtual = textoAtual.replace("%", "");
        
        if (digitarNovoNumero) {
            // Se for novo número, começa com o dígito
            textoAtual = digito;
            digitarNovoNumero = false;
        } else if (textoAtual.equals("0")) {
            // Se está em 0, substitui
            textoAtual = digito;
        } else if (textoAtual.equals("-0")) {
            // Se está em -0, mantém o sinal
            textoAtual = "-" + digito;
        } else {
            // Adiciona o dígito ao número existente
            textoAtual += digito;
        }
        
        view.setTextoVisor(textoAtual);
    }
    
    private void adicionarPontoDecimal() {
        String textoAtual = view.getTextoVisor();
        textoAtual = textoAtual.replace("%", "");
        
        if (digitarNovoNumero) {
            textoAtual = "0.";
            digitarNovoNumero = false;
        } else if (textoAtual.equals("0")) {
            textoAtual = "0.";
        } else if (textoAtual.equals("-0")) {
            textoAtual = "-0.";
        } else if (!textoAtual.contains(".")) {
            textoAtual += ".";
        }
        
        view.setTextoVisor(textoAtual);
    }
    
    private void alternarSinal() {
        String textoAtual = view.getTextoVisor();
        
        // Remove símbolo % se presente
        textoAtual = textoAtual.replace("%", "");
        
        // Se está em modo de digitar novo número
        if (digitarNovoNumero) {
            // Se o visor mostra "0", muda para "-0"
            if (textoAtual.equals("0")) {
                view.setTextoVisor("-0");
            }
            // Se o visor mostra "-0", muda para "0"
            else if (textoAtual.equals("-0")) {
                view.setTextoVisor("0");
            }
            // Caso contrário, inverte o sinal do que está no visor
            else {
                inverterSinalTexto(textoAtual);
            }
            digitarNovoNumero = false;
        } else {
            // Não está em modo novo número, inverte o sinal normalmente
            inverterSinalTexto(textoAtual);
        }
    }
    
    private void inverterSinalTexto(String texto) {
        // Substitui vírgula por ponto para parse correto
        String textoParaParse = texto.replace(",", ".");
        
        try {
            // Tenta converter para número
            double valor = Double.parseDouble(textoParaParse);
            valor = -valor;
            
            // Formata de volta mantendo o formato original
            String resultado = formatarNumeroParaVisor(valor);
            view.setTextoVisor(resultado);
            
        } catch (NumberFormatException e) {
            // Se não conseguir converter, usa lógica simples de string
            if (texto.startsWith("-")) {
                texto = texto.substring(1);
            } else {
                texto = "-" + texto;
            }
            view.setTextoVisor(texto);
        }
    }
    
    private String formatarNumeroParaVisor(double valor) {
        // Formata o número com ponto como separador decimal
        // Sem separadores de milhar
        if (valor == Math.floor(valor) && !Double.isInfinite(valor)) {
            // É inteiro
            return String.format("%.0f", valor);
        } else {
            // Tem casas decimais - formata com 2 casas
            return String.format("%.2f", valor);
        }
    }
    
    private double parseValorDoVisor() throws NumberFormatException {
        String textoVisor = view.getTextoVisor()
            .replace("%", "")
            .replace(",", "."); // Substitui vírgula por ponto para parse
        
        return Double.parseDouble(textoVisor);
    }
    
    private void executarOperacao(String operacao) {
        try {
            double valorAtual = parseValorDoVisor();
            
            if (!model.isAguardandoNovoValor()) {
                // Primeiro operando
                model.setValorAnterior(valorAtual);
                model.setAguardandoNovoValor(true);
                view.setTextoVisor(formatarNumeroParaVisor(valorAtual));
            } else {
                // Já tem um operando, executa a operação anterior
                double resultado = model.executarOperacao(model.getUltimaOperacao(), 
                    model.getValorAnterior(), valorAtual);
                view.setTextoVisor(formatarNumeroParaVisor(resultado));
                model.setValorAnterior(resultado);
            }
            
            model.setUltimaOperacao(operacao);
            digitarNovoNumero = true;
            
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        } catch (Exception e) {
            view.mostrarErro("Erro na operação: " + e.getMessage());
        }
    }
    
    private void finalizarOperacao() {
        try {
            if (model.isAguardandoNovoValor() && !model.getUltimaOperacao().isEmpty()) {
                double valorAtual = parseValorDoVisor();
                
                double resultado = model.executarOperacao(model.getUltimaOperacao(), 
                    model.getValorAnterior(), valorAtual);
                
                view.setTextoVisor(formatarNumeroParaVisor(resultado));
                model.setValorAnterior(resultado);
                model.setAguardandoNovoValor(false);
                digitarNovoNumero = true;
            }
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        } catch (Exception e) {
            view.mostrarErro("Erro na operação: " + e.getMessage());
        }
    }
    
    private void executarEnter() {
        try {
            double valorAtual = parseValorDoVisor();
            model.setValorAnterior(valorAtual);
            model.setAguardandoNovoValor(true);
            digitarNovoNumero = true;
            view.setTextoVisor(formatarNumeroParaVisor(valorAtual));
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        }
    }

    
    private void executarFuncaoFinanceira(String funcao) {
    	debugRegistros("Antes de " + funcao);
        try {
            double valorAtual = parseValorDoVisor();
            
            // Armazena o valor do visor no registro
            model.setRegistro(funcao, valorAtual);
            
            // Verifica se pode calcular esta função
            if (podeCalcularFuncao(funcao)) {
                // Tenta calcular
                try {
                    double resultado = model.calcularFuncaoFinanceira(funcao);
                    
                    // Formata o resultado
                    String resultadoFormatado;
                    if (funcao.equals(CalculadoraHPModel.TAXA)) {
                        // Para taxa, mostra como percentual com 2 casas
                        resultadoFormatado = String.format("%.2f%%", resultado);
                    } else {
                        resultadoFormatado = formatarNumeroParaVisor(resultado);
                    }
                    
                    view.setTextoVisor(resultadoFormatado);
                    
                    // Atualiza o registro com o valor calculado
                    model.setRegistro(funcao, resultado);
                    
                    view.mostrarMensagem(funcao + " calculado: " + resultadoFormatado);
                    
                } catch (Exception e) {
                    // Não conseguiu calcular, apenas mostra o valor armazenado
                    view.setTextoVisor(formatarNumeroParaVisor(valorAtual));
                    view.mostrarMensagem("Armazenado " + funcao + ": " + 
                        formatarNumeroParaVisor(valorAtual));
                }
            } else {
                // Apenas armazena (não tem valores suficientes para calcular)
                view.setTextoVisor(formatarNumeroParaVisor(valorAtual));
                view.mostrarMensagem("Armazenado " + funcao + ": " + 
                    formatarNumeroParaVisor(valorAtual));
            }
            
            // Atualiza view
            atualizarView();
            digitarNovoNumero = true;
            
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido: " + view.getTextoVisor());
        } catch (Exception e) {
            view.mostrarErro("Erro: " + e.getMessage());
        }
    }
    
    private boolean podeCalcularFuncao(String funcaoParaCalcular) {
        // Verifica se pode calcular uma função específica
        // Para calcular, precisamos ter valores em todas as outras variáveis
        
        double vp = model.getRegistro(CalculadoraHPModel.VP);
        double vf = model.getRegistro(CalculadoraHPModel.VF);
        double pmt = model.getRegistro(CalculadoraHPModel.PMT);
        double i = model.getRegistro(CalculadoraHPModel.TAXA);
        double n = model.getRegistro(CalculadoraHPModel.PERIODO);
        
        // Verifica quantas variáveis estão preenchidas (diferente de 0)
        int preenchidas = 0;
        if (vp != 0) preenchidas++;
        if (vf != 0) preenchidas++;
        if (pmt != 0) preenchidas++;
        if (i != 0) preenchidas++;
        if (n != 0) preenchidas++;
        
        // Para calcular uma função, precisamos ter exatamente 4 variáveis preenchidas
        // (a quinta é a que queremos calcular)
        if (preenchidas == 4) {
            // A função que queremos calcular deve ser a única vazia (0)
            double valorFuncao = model.getRegistro(funcaoParaCalcular);
            
            // Se o valor atual dessa função for 0, ou se estamos pressionando
            // o botão da função que já tem um valor (para recalcular)
            if (valorFuncao == 0 || true) { // Sempre tenta calcular se temos 4 valores
                // Verifica se temos os valores mínimos necessários
                // Para calcular TAXA (i), precisamos de VP, VF e n
                if (funcaoParaCalcular.equals(CalculadoraHPModel.TAXA)) {
                    return vp != 0 && vf != 0 && n != 0;
                }
                // Para calcular PERIODO (n), precisamos de VP, VF e i
                else if (funcaoParaCalcular.equals(CalculadoraHPModel.PERIODO)) {
                    return vp != 0 && vf != 0 && i != 0;
                }
                // Para outras funções, verifica se temos valores suficientes
                else {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    private void limparTudo() {
        model.limparTudo();
        view.setTextoVisor("0");
        digitarNovoNumero = true;
        ultimaFuncaoFinanceira = "";
        atualizarView();
    }
    
    private void atualizarView() {
        view.atualizarPainelInformacoes(model.getTodosRegistros());
    }
    
    public void iniciar() {
        view.setVisible(true);
    }
    
    
    private void debugRegistros(String operacao) {
        System.out.println("=== DEBUG " + operacao + " ===");
        System.out.println("VP: " + model.getRegistro(CalculadoraHPModel.VP));
        System.out.println("VF: " + model.getRegistro(CalculadoraHPModel.VF));
        System.out.println("n: " + model.getRegistro(CalculadoraHPModel.PERIODO));
        System.out.println("i: " + model.getRegistro(CalculadoraHPModel.TAXA));
        System.out.println("======================");
    }
}