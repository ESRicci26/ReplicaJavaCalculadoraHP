package javaricci.com.br.view;

import javaricci.com.br.model.CalculadoraHPModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.Map;

/**
 * View da Calculadora HP12C - Responsável pela interface gráfica
 */
public class CalculadoraHPView extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private final JTextField campoTextoVisor;
    private final DecimalFormat formatoDecimal;
    private final JPanel painelInfo;
    
    // Botões que serão conectados ao controller
    private final JButton[] botoesNumericos = new JButton[10];
    private final JButton btnPonto;
    private final JButton btnMais;
    private final JButton btnMenos;
    private final JButton btnMultiplicar;
    private final JButton btnDividir;
    private final JButton btnIgual;
    private final JButton btnLimpar;
    private final JButton btnCHS;
    private final JButton btnEnter;
    
    // Botões financeiros
    private final JButton btnVP;
    private final JButton btnVF;
    private final JButton btnPMT;
    private final JButton btnTaxa;
    private final JButton btnPeriodo;

    public CalculadoraHPView() {
        formatoDecimal = new DecimalFormat("#,##0.00");
        campoTextoVisor = new JTextField("0");
        
        // Inicializa botões
        for (int i = 0; i < 10; i++) {
            botoesNumericos[i] = new JButton(String.valueOf(i));
        }
        
        btnPonto = new JButton(".");
        btnMais = new JButton("+");
        btnMenos = new JButton("-");
        btnMultiplicar = new JButton("×");
        btnDividir = new JButton("÷");
        btnIgual = new JButton("=");
        btnLimpar = new JButton("C");
        btnCHS = new JButton("CHS");
        btnEnter = new JButton("ENTER");
        
        btnVP = new JButton("VP");
        btnVF = new JButton("VF");
        btnPMT = new JButton("PMT");
        btnTaxa = new JButton("i");
        btnPeriodo = new JButton("n");
        
        painelInfo = criarPainelInformacoes();
        
        inicializarComponentes();
    }
    
    private void inicializarComponentes() {
        campoTextoVisor.setFont(new Font("Consolas", Font.BOLD, 24));
        campoTextoVisor.setHorizontalAlignment(JTextField.RIGHT);
        campoTextoVisor.setPreferredSize(new Dimension(350, 50));
        campoTextoVisor.setEditable(true);

        // Configuração da janela
        setTitle("Calculadora HP Financeira");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        
        // Layout principal
        JPanel painelPrincipal = new JPanel(new BorderLayout());
        
        // Painel do visor
        JPanel painelVisor = new JPanel(new BorderLayout());
        painelVisor.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        painelVisor.add(campoTextoVisor, BorderLayout.CENTER);
        
        // Painel dos botões
        JPanel painelBotoes = new JPanel(new GridLayout(6, 4, 5, 5));
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        
        // Primeira linha: Funções financeiras
        configurarBotao(btnVP, Color.BLUE, "Clique para calcular VP ou armazenar valor");
        configurarBotao(btnVF, Color.BLUE, "Clique para calcular VF ou armazenar valor");
        configurarBotao(btnPMT, Color.BLUE, "Clique para calcular PMT ou armazenar valor");
        configurarBotao(btnLimpar, Color.RED, null);
        
        painelBotoes.add(btnVP);
        painelBotoes.add(btnVF);
        painelBotoes.add(btnPMT);
        painelBotoes.add(btnLimpar);
        
        // Segunda linha: Mais funções financeiras
        configurarBotao(btnTaxa, Color.BLUE, "Clique para calcular i ou armazenar valor");
        configurarBotao(btnPeriodo, Color.BLUE, "Clique para calcular n ou armazenar valor");
        configurarBotao(btnCHS, Color.ORANGE, null);
        configurarBotao(btnDividir, Color.GRAY, null);
        
        painelBotoes.add(btnTaxa);
        painelBotoes.add(btnPeriodo);
        painelBotoes.add(btnCHS);
        painelBotoes.add(btnDividir);
        
        // Terceira linha: 7, 8, 9, *
        configurarBotaoNumerico(botoesNumericos[7]);
        configurarBotaoNumerico(botoesNumericos[8]);
        configurarBotaoNumerico(botoesNumericos[9]);
        configurarBotao(btnMultiplicar, Color.GRAY, null);
        
        painelBotoes.add(botoesNumericos[7]);
        painelBotoes.add(botoesNumericos[8]);
        painelBotoes.add(botoesNumericos[9]);
        painelBotoes.add(btnMultiplicar);
        
        // Quarta linha: 4, 5, 6, -
        configurarBotaoNumerico(botoesNumericos[4]);
        configurarBotaoNumerico(botoesNumericos[5]);
        configurarBotaoNumerico(botoesNumericos[6]);
        configurarBotao(btnMenos, Color.GRAY, null);
        
        painelBotoes.add(botoesNumericos[4]);
        painelBotoes.add(botoesNumericos[5]);
        painelBotoes.add(botoesNumericos[6]);
        painelBotoes.add(btnMenos);
        
        // Quinta linha: 1, 2, 3, +
        configurarBotaoNumerico(botoesNumericos[1]);
        configurarBotaoNumerico(botoesNumericos[2]);
        configurarBotaoNumerico(botoesNumericos[3]);
        configurarBotao(btnMais, Color.GRAY, null);
        
        painelBotoes.add(botoesNumericos[1]);
        painelBotoes.add(botoesNumericos[2]);
        painelBotoes.add(botoesNumericos[3]);
        painelBotoes.add(btnMais);
        
        // Sexta linha: 0, ., =, ENTER
        configurarBotaoNumerico(botoesNumericos[0]);
        configurarBotao(btnPonto, Color.LIGHT_GRAY, null);
        configurarBotao(btnIgual, Color.GREEN, null);
        configurarBotao(btnEnter, Color.GREEN, null);
        
        painelBotoes.add(botoesNumericos[0]);
        painelBotoes.add(btnPonto);
        painelBotoes.add(btnIgual);
        painelBotoes.add(btnEnter);

        painelPrincipal.add(painelVisor, BorderLayout.NORTH);
        painelPrincipal.add(painelBotoes, BorderLayout.CENTER);
        painelPrincipal.add(painelInfo, BorderLayout.SOUTH);
        
        add(painelPrincipal);
        pack();
        setLocationRelativeTo(null);
    }
    
    private void configurarBotaoNumerico(JButton botao) {
        configurarBotao(botao, Color.LIGHT_GRAY, null);
    }
    
    private void configurarBotao(JButton botao, Color cor, String tooltip) {
        botao.setFont(new Font("Consolas", Font.BOLD, 14));
        botao.setPreferredSize(new Dimension(70, 40));
        botao.setFocusPainted(false);
        botao.setBackground(cor);
        if (tooltip != null) {
            botao.setToolTipText(tooltip);
        }
    }
    
    private JPanel criarPainelInformacoes() {
        JPanel painel = new JPanel(new GridLayout(1, 5, 5, 5));
        painel.setBorder(BorderFactory.createTitledBorder("Registros Financeiros"));
        painel.setPreferredSize(new Dimension(350, 60));
        
        String[] registros = {
            CalculadoraHPModel.VP,
            CalculadoraHPModel.VF,
            CalculadoraHPModel.PMT,
            CalculadoraHPModel.TAXA,
            CalculadoraHPModel.PERIODO
        };
        
        for (String registro : registros) {
            JLabel label = new JLabel(registro + ": 0.00", SwingConstants.CENTER);
            label.setFont(new Font("Consolas", Font.PLAIN, 10));
            label.setBorder(BorderFactory.createEtchedBorder());
            painel.add(label);
        }
        
        return painel;
    }
    
    // Métodos públicos para o Controller
    
    public String getTextoVisor() {
        return campoTextoVisor.getText();
    }
    
    public void setTextoVisor(String texto) {
        campoTextoVisor.setText(texto);
    }
    
    public String formatarNumero(double numero) {
        if (Math.abs(numero) < 0.01 && numero != 0) {
            return String.format("%.6f", numero);
        }
        return formatoDecimal.format(numero);
    }
    
    public void atualizarPainelInformacoes(Map<String, Double> registros) {
        Component[] componentes = painelInfo.getComponents();
        String[] chaves = {
            CalculadoraHPModel.VP,
            CalculadoraHPModel.VF,
            CalculadoraHPModel.PMT,
            CalculadoraHPModel.TAXA,
            CalculadoraHPModel.PERIODO
        };
        
        for (int i = 0; i < chaves.length && i < componentes.length; i++) {
            if (componentes[i] instanceof JLabel) {
                JLabel label = (JLabel) componentes[i];
                double valor = registros.getOrDefault(chaves[i], 0.0);
                String texto = chaves[i] + ": " + formatarNumero(valor);
                if (chaves[i].equals(CalculadoraHPModel.TAXA)) {
                    texto += "%";
                }
                label.setText(texto);
            }
        }
    }
    
    public void mostrarMensagem(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Informação", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void mostrarErro(String erro) {
        JOptionPane.showMessageDialog(this, erro, "Erro", JOptionPane.ERROR_MESSAGE);
    }
    
    // Métodos para adicionar listeners (usados pelo Controller)
    
    public void addBotaoNumericoListener(int numero, ActionListener listener) {
        botoesNumericos[numero].addActionListener(listener);
    }
    
    public void addBotaoPontoListener(ActionListener listener) {
        btnPonto.addActionListener(listener);
    }
    
    public void addBotaoOperacaoListener(String operacao, ActionListener listener) {
        switch (operacao) {
            case "+":
                btnMais.addActionListener(listener);
                break;
            case "-":
                btnMenos.addActionListener(listener);
                break;
            case "*":
                btnMultiplicar.addActionListener(listener);
                break;
            case "/":
                btnDividir.addActionListener(listener);
                break;
        }
    }
    
    public void addBotaoIgualListener(ActionListener listener) {
        btnIgual.addActionListener(listener);
    }
    
    public void addBotaoLimparListener(ActionListener listener) {
        btnLimpar.addActionListener(listener);
    }
    
    public void addBotaoCHSListener(ActionListener listener) {
        btnCHS.addActionListener(listener);
    }
    
    public void addBotaoEnterListener(ActionListener listener) {
        btnEnter.addActionListener(listener);
        campoTextoVisor.addActionListener(listener); // ENTER do teclado também
    }
    
    public void addBotaoFinanceiroListener(String funcao, ActionListener listener) {
        switch (funcao) {
            case CalculadoraHPModel.VP:
                btnVP.addActionListener(listener);
                break;
            case CalculadoraHPModel.VF:
                btnVF.addActionListener(listener);
                break;
            case CalculadoraHPModel.PMT:
                btnPMT.addActionListener(listener);
                break;
            case CalculadoraHPModel.TAXA:
                btnTaxa.addActionListener(listener);
                break;
            case CalculadoraHPModel.PERIODO:
                btnPeriodo.addActionListener(listener);
                break;
        }
    }
}