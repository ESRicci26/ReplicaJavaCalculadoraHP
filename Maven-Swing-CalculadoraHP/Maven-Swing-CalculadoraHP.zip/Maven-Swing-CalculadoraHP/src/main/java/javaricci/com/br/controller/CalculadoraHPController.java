package javaricci.com.br.controller;

import javaricci.com.br.model.CalculadoraHPModel;
import javaricci.com.br.view.CalculadoraHPView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Controller da Calculadora HP12C - Responsável pela coordenação entre Model e View
 */
public class CalculadoraHPController {
    private final CalculadoraHPModel model;
    private final CalculadoraHPView view;
    
    private boolean digitarNovoNumero = true;
    private boolean valorNegativo = false;
    
    public CalculadoraHPController(CalculadoraHPModel model, CalculadoraHPView view) {
        this.model = model;
        this.view = view;
        
        configurarListeners();
        atualizarView();
    }
    
    private void configurarListeners() {
        // Listeners para botões numéricos
        for (int i = 0; i < 10; i++) {
            final int numero = i;
            view.addBotaoNumericoListener(numero, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarDigito(String.valueOf(numero));
                }
            });
        }
        
        // Listener para ponto decimal
        view.addBotaoPontoListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarPontoDecimal();
            }
        });
        
        // Listeners para operações básicas
        String[] operacoes = {"+", "-", "*", "/"};
        for (String operacao : operacoes) {
            view.addBotaoOperacaoListener(operacao, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    executarOperacao(operacao);
                }
            });
        }
        
        // Listener para igual
        view.addBotaoIgualListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finalizarOperacao();
            }
        });
        
        // Listener para limpar
        view.addBotaoLimparListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limparTudo();
            }
        });
        
        // Listener para CHS (mudar sinal)
        view.addBotaoCHSListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alternarSinal();
            }
        });
        
        // Listener para ENTER
        view.addBotaoEnterListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executarEnter();
            }
        });
        
        // Listeners para funções financeiras
        String[] funcoesFinanceiras = {
            CalculadoraHPModel.VP,
            CalculadoraHPModel.VF,
            CalculadoraHPModel.PMT,
            CalculadoraHPModel.TAXA,
            CalculadoraHPModel.PERIODO
        };
        
        for (String funcao : funcoesFinanceiras) {
            view.addBotaoFinanceiroListener(funcao, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    executarFuncaoFinanceira(funcao);
                }
            });
        }
    }
    
    private void adicionarDigito(String digito) {
        String textoAtual = view.getTextoVisor();
        
        if (digitarNovoNumero || textoAtual.equals("0")) {
            if (valorNegativo) {
                textoAtual = "-" + digito;
                valorNegativo = false;
            } else {
                textoAtual = digito;
            }
            digitarNovoNumero = false;
        } else {
            textoAtual += digito;
        }
        
        view.setTextoVisor(textoAtual);
    }
    
    private void adicionarPontoDecimal() {
        String textoAtual = view.getTextoVisor();
        
        if (digitarNovoNumero) {
            if (valorNegativo) {
                textoAtual = "-0.";
                valorNegativo = false;
            } else {
                textoAtual = "0.";
            }
            digitarNovoNumero = false;
        } else if (!textoAtual.contains(".")) {
            textoAtual += ".";
        }
        
        view.setTextoVisor(textoAtual);
    }
    
    private void alternarSinal() {
        String textoAtual = view.getTextoVisor();
        
        if (textoAtual.startsWith("-")) {
            textoAtual = textoAtual.substring(1);
        } else {
            textoAtual = "-" + textoAtual;
        }
        
        // Se estiver esperando novo número, marca como negativo
        if (digitarNovoNumero) {
            valorNegativo = !valorNegativo;
            textoAtual = valorNegativo ? "-0" : "0";
        }
        
        view.setTextoVisor(textoAtual);
    }
    
    private void executarOperacao(String operacao) {
        try {
            double valorAtual = Double.parseDouble(view.getTextoVisor());
            
            if (!model.isAguardandoNovoValor()) {
                model.setValorAnterior(valorAtual);
                model.setAguardandoNovoValor(true);
            } else {
                double resultado = model.executarOperacao(model.getUltimaOperacao(), 
                    model.getValorAnterior(), valorAtual);
                view.setTextoVisor(view.formatarNumero(resultado));
                model.setValorAnterior(resultado);
            }
            
            model.setUltimaOperacao(operacao);
            digitarNovoNumero = true;
            
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        } catch (Exception e) {
            view.mostrarErro("Erro na operação: " + e.getMessage());
        }
    }
    
    private void finalizarOperacao() {
        try {
            if (model.isAguardandoNovoValor() && !model.getUltimaOperacao().isEmpty()) {
                double valorAtual = Double.parseDouble(view.getTextoVisor());
                double resultado = model.executarOperacao(model.getUltimaOperacao(), 
                    model.getValorAnterior(), valorAtual);
                
                view.setTextoVisor(view.formatarNumero(resultado));
                model.setValorAnterior(resultado);
                model.setAguardandoNovoValor(false);
                digitarNovoNumero = true;
            }
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        } catch (Exception e) {
            view.mostrarErro("Erro na operação: " + e.getMessage());
        }
    }
    
    private void executarEnter() {
        try {
            double valorAtual = Double.parseDouble(view.getTextoVisor());
            model.setValorAnterior(valorAtual);
            model.setAguardandoNovoValor(true);
            digitarNovoNumero = true;
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        }
    }
    
    private void executarFuncaoFinanceira(String funcao) {
        try {
            double valorAtual = Double.parseDouble(view.getTextoVisor());
            
            // Armazena o valor do visor no registro correspondente
            model.setRegistro(funcao, valorAtual);
            
            // Tenta calcular a função se possível
            try {
                double resultado = model.calcularFuncaoFinanceira(funcao);
                
                // Se cálculo foi bem-sucedido, exibe no visor
                view.setTextoVisor(view.formatarNumero(resultado));
                
                // Se for taxa, mostra como percentual
                if (funcao.equals(CalculadoraHPModel.TAXA)) {
                    view.setTextoVisor(view.formatarNumero(resultado) + "%");
                }
                
                // Atualiza o registro com o valor calculado
                model.setRegistro(funcao, resultado);
                
            } catch (Exception e) {
                // Apenas armazena o valor sem calcular
                view.mostrarMensagem("Valor " + funcao + " armazenado: " + valorAtual);
            }
            
            // Atualiza a view com os registros
            atualizarView();
            digitarNovoNumero = true;
            
        } catch (NumberFormatException e) {
            view.mostrarErro("Valor inválido no visor: " + view.getTextoVisor());
        } catch (Exception e) {
            view.mostrarErro("Erro na função financeira: " + e.getMessage());
        }
    }
    
    private void limparTudo() {
        model.limparTudo();
        view.setTextoVisor("0");
        digitarNovoNumero = true;
        valorNegativo = false;
        atualizarView();
    }
    
    private void atualizarView() {
        view.atualizarPainelInformacoes(model.getTodosRegistros());
    }
    
    public void iniciar() {
        view.setVisible(true);
    }
}