package javaricci.com.br;

import javaricci.com.br.controller.CalculadoraHPController;
import javaricci.com.br.model.CalculadoraHPModel;
import javaricci.com.br.view.CalculadoraHPView;

import javax.swing.*;

/**
 * Classe principal da aplicação Calculadora HP12C
 * Inicializa o padrão MVC e inicia a aplicação
 */
public class CalculadoraHPApp {
    public static void main(String[] args) {
        // Executa no Event Dispatch Thread do Swing
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    // Define o look and feel do sistema
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                    
                    // Inicializa os componentes do MVC
                    CalculadoraHPModel model = new CalculadoraHPModel();
                    CalculadoraHPView view = new CalculadoraHPView();
                    CalculadoraHPController controller = new CalculadoraHPController(model, view);
                    
                    // Inicia a aplicação
                    controller.iniciar();
                    
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(
                        null,
                        "Erro ao iniciar a calculadora: " + e.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        });
    }
}