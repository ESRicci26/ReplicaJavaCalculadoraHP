package javaricci.com.br.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Model da Calculadora HP12C - Responsável pela lógica de negócio e dados
 */
public class CalculadoraHPModel {
    
    // Registros financeiros
    public static final String VP = "VP"; // Valor Presente
    public static final String VF = "VF"; // Valor Futuro  
    public static final String PMT = "PMT"; // Pagamento
    public static final String TAXA = "i"; // Taxa de juros ao mês
    public static final String PERIODO = "n"; // Número de períodos
    
    private final Map<String, Double> registrosFinanceiros;
    private String ultimaOperacao = "";
    private boolean aguardandoNovoValor = false;
    private double valorAnterior = 0;

    public CalculadoraHPModel() {
        registrosFinanceiros = new HashMap<>();
        inicializarRegistros();
    }
    
    private void inicializarRegistros() {
        registrosFinanceiros.put(VP, 0.0);
        registrosFinanceiros.put(VF, 0.0);
        registrosFinanceiros.put(PMT, 0.0);
        registrosFinanceiros.put(TAXA, 0.0);
        registrosFinanceiros.put(PERIODO, 0.0);
    }
    
    public void limparTudo() {
        inicializarRegistros();
        aguardandoNovoValor = false;
        ultimaOperacao = "";
        valorAnterior = 0;
    }
    
    public void setRegistro(String chave, double valor) {
        registrosFinanceiros.put(chave, valor);
    }
    
    public double getRegistro(String chave) {
        return registrosFinanceiros.getOrDefault(chave, 0.0);
    }
    
    public Map<String, Double> getTodosRegistros() {
        return new HashMap<>(registrosFinanceiros);
    }
    
    public boolean isAguardandoNovoValor() {
        return aguardandoNovoValor;
    }
    
    public void setAguardandoNovoValor(boolean aguardando) {
        this.aguardandoNovoValor = aguardando;
    }
    
    public void setUltimaOperacao(String operacao) {
        this.ultimaOperacao = operacao;
    }
    
    public String getUltimaOperacao() {
        return ultimaOperacao;
    }
    
    public void setValorAnterior(double valor) {
        this.valorAnterior = valor;
    }
    
    public double getValorAnterior() {
        return valorAnterior;
    }
    
    /**
     * Executa operação matemática básica
     */
    public double executarOperacao(String operacao, double valor1, double valor2) throws Exception {
        switch (operacao) {
            case "+":
                return valor1 + valor2;
            case "-":
                return valor1 - valor2;
            case "*":
                return valor1 * valor2;
            case "/":
                if (valor2 == 0) {
                    throw new Exception("Não é possível dividir por zero");
                }
                return valor1 / valor2;
            default:
                throw new Exception("Operação desconhecida");
        }
    }
    
    /**
     * Calcula função financeira baseada nos registros atuais
     */
    public double calcularFuncaoFinanceira(String funcao) throws Exception {
        double vp = registrosFinanceiros.get(VP);
        double vf = registrosFinanceiros.get(VF);
        double pmt = registrosFinanceiros.get(PMT);
        double i = registrosFinanceiros.get(TAXA) / 100.0; // Converte percentual para decimal
        double n = registrosFinanceiros.get(PERIODO);
        
        switch (funcao) {
            case VP:
                return calcularVP(vf, pmt, i, n);
            case VF:
                return calcularVF(vp, pmt, i, n);
            case PMT:
                return calcularPMT(vp, vf, i, n);
            case TAXA:
                return calcularJurosMensalComRegistros();
            case PERIODO:
                return calcularQuantidadeMesesComRegistros();
            default:
                throw new Exception("Função financeira desconhecida: " + funcao);
        }
    }
    
    private double calcularVP(double vf, double pmt, double i, double n) throws Exception {
        if (n <= 0) {
            throw new Exception("Número de períodos (n) deve ser maior que zero para calcular VP. Valor atual: " + n);
        }
        if (i == 0) {
            return -(vf + pmt * n);
        }
        return -(vf / Math.pow(1 + i, n) + pmt * ((1 - Math.pow(1 + i, -n)) / i));
    }
    
    private double calcularVF(double vp, double pmt, double i, double n) throws Exception {
        if (n <= 0) {
            throw new Exception("Número de períodos (n) deve ser maior que zero para calcular VF. Valor atual: " + n);
        }
        if (i == 0) {
            return -(vp + pmt * n);
        }
        return -(vp * Math.pow(1 + i, n) + pmt * ((Math.pow(1 + i, n) - 1) / i));
    }
    
    private double calcularPMT(double vp, double vf, double i, double n) throws Exception {
        if (n <= 0) {
            throw new Exception("Número de períodos (n) deve ser maior que zero para calcular PMT. Valor atual: " + n);
        }
        if (i == 0) {
            return -(vp + vf) / n;
        }
        return -(vp * i * Math.pow(1 + i, n) + vf * i) / (Math.pow(1 + i, n) - 1);
    }
    
    /**
     * Calcula a taxa de juros mensal usando VF, VP e n
     * Fórmula: i = ((VF/VP)^(1/n)) - 1
     */
    private double calcularJurosMensalComRegistros() throws Exception {
        double vf = registrosFinanceiros.get(VF);
        double vp = registrosFinanceiros.get(VP);
        double n = registrosFinanceiros.get(PERIODO);
        
        if (vf == 0 && vp == 0 && n == 0) {
            throw new Exception("É necessário ter valores em VF, VP e n para calcular a taxa de juros");
        }
        
        return calcularJurosMensal(vf, vp, n);
    }
    
    private double calcularJurosMensal(double vf, double vp, double n) throws Exception {
        if (n <= 0) {
            throw new Exception("Número de períodos (n) deve ser maior que zero. Valor atual: " + n);
        }
        if (vp == 0) {
            throw new Exception("Valor Presente (VP) não pode ser zero");
        }
        if (vf == 0) {
            throw new Exception("Valor Futuro (VF) não pode ser zero");
        }
        if (vf * vp < 0) {
            throw new Exception("VF e VP devem ter sinais opostos (um positivo e outro negativo)");
        }
        
        double razao = Math.abs(vf / vp);
        double taxa = Math.pow(razao, 1.0 / n) - 1;
        
        return taxa * 100; // Retorna em percentual
    }
    
    /**
     * Calcula o número de meses usando VF, VP e i
     * Fórmula: n = ln(VF/VP) / ln(1 + i)
     */
    private double calcularQuantidadeMesesComRegistros() throws Exception {
        double vf = registrosFinanceiros.get(VF);
        double vp = registrosFinanceiros.get(VP);
        double i = registrosFinanceiros.get(TAXA) / 100.0;
        
        if (vf == 0 && vp == 0 && registrosFinanceiros.get(TAXA) == 0) {
            throw new Exception("É necessário ter valores em VF, VP e i para calcular o número de períodos");
        }
        
        return calcularQuantidadeMeses(vf, vp, i);
    }
    
    private double calcularQuantidadeMeses(double vf, double vp, double i) throws Exception {
        if (vp == 0) {
            throw new Exception("Valor Presente (VP) não pode ser zero");
        }
        if (vf == 0) {
            throw new Exception("Valor Futuro (VF) não pode ser zero");
        }
        if (vf * vp < 0) {
            throw new Exception("VF e VP devem ter sinais opostos (um positivo e outro negativo)");
        }
        if (i <= -1) {
            throw new Exception("Taxa de juros deve ser maior que -100%");
        }
        
        double razao = Math.abs(vf / vp);
        if (razao <= 1 && i >= 0) {
            throw new Exception("Com taxa positiva, VF deve ser maior que VP em valor absoluto");
        }
        if (razao >= 1 && i <= 0) {
            throw new Exception("Com taxa negativa, VP deve ser maior que VF em valor absoluto");
        }
        
        double numerador = Math.log(razao);
        double denominador = Math.log(1 + i);
        
        if (Math.abs(denominador) < 1e-10) {
            throw new Exception("Taxa muito próxima de zero para cálculo preciso");
        }
        
        return numerador / denominador;
    }
}